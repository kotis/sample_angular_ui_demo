import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import * as XLSX from 'xlsx';
import { ValidationService } from "../validation.service";
import { TableModule } from 'primeng/table';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
  imports: [CommonModule, FormsModule, TableModule]
})
export class HomeComponent {
  selectedSheet = "";
  enableValidation = false;

  selectedFile: File | null = null;
  sheetNames: string[] = [];
  sessionGuid = '';
  errors: any[] = [];

  constructor(private validationService: ValidationService) {

  }

  public onFilesSelected(event: any) {
    this.selectedSheet = "";
    this.selectedFile = event.target.files[0];
    const target: DataTransfer = <DataTransfer>(event.target);
    if (target.files.length !== 1) {
      alert('Please select a single file.');
      return;
    }

    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      this.sheetNames = wb.SheetNames;
    };
    reader.readAsDataURL(target.files[0]);
  }

  public loadFile() {
    if (this.selectedFile) {
      this.validationService.uploadFile(this.selectedFile, this.selectedSheet).subscribe({
        next: (response) => {
          console.log(response);
          this.sessionGuid = response;
          this.enableValidation = true;
        },
        error: (error) => {
          console.error('Upload failed', error);
        }
      })
    }
  }

  public validate() {
    this.validationService.validate(this.sessionGuid).subscribe({
      next: (res) => {
        console.log(res);
        this.errors = res;
      }
    });
  }
}

