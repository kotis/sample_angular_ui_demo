import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  private apiUrl = 'http://localhost:3000/excel-validation/savetostg';
  constructor(private http: HttpClient) { }
  uploadFile(file: File, sheetName: string): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('sheetName', sheetName);
    return this.http.post(this.apiUrl, formData, { responseType: 'text' });
  }

  validate(sessionGuid: string) {
    return this.http.get<any>("http://localhost:3000/excel-validation/geterrors", {params: {
      sessionGuid
    }});
  }
}
