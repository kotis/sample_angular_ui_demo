import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
  imports:[CommonModule, FormsModule]
})
export class HomeComponent {
  title = 'excel-validator-kote';
  selectedSheet = "";

  selectedFile: File | null = null;
  sheetNames: string[] = [];

  public onFilesSelected(event: any) {
    const target: DataTransfer = <DataTransfer>(event.target);
    if (target.files.length !== 1) {
      alert('Please select a single file.');
      return;
    }

    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      // Get the list of sheet names
      this.sheetNames = wb.SheetNames;
    };
    reader.readAsBinaryString(target.files[0]);
  }
}
